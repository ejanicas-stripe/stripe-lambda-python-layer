from typing import Union, TypeVar

T = TypeVar("T")
ExpandableField = Union[str, T]
